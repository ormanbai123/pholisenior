
#include "includes.h"
#include <string>
#include <vector>

template< typename T1, typename T2 >
concept ignoring_cvref = std::same_as< std::remove_cvref_t<T1>, T2> ;

template< ignoring_cvref< int > I >
void print( I&& i )
{
   std::cout << i << "\n";
}

int main( int argc, char* argv[] )
{
   const int i = 100;
   print(i+50);
   return 0;

   std::string ss = "hans de nivelle"; 

   auto p = takeshare( tvm::constr_scalar_repeated< std::string, std::string > ( std::move(ss), 1 ));
  
   std::cout << "moved " << ss << "\n";

   auto p1 = takeshare(p);
 
   std::cout << p -> size( ) << "/" << p -> capacity( ) << "\n";

   
   std::vector< std::string > rep = { "sasha", "valerievna", "kireeva" };

   for( auto& s : rep )
   {
      p = push_back(p, s);
      p = push_back(p, s);
      p = push_back(p, std::move(s));
   }

   for( const auto& s : rep )
      std::cout << "moved-out: " << s << "\n";
   std::cout << p -> scal << "\n";

   for( size_t i = 0; i != p -> size( ); ++ i )
      std::cout << p -> begin( )[i] << "\n";

   dropshare(p);    
   dropshare(p1);

   return 0;

}

